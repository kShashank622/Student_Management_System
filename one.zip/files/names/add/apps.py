from django.apps import AppConfig


class AddConfig(AppConfig):
    name = 'add'
