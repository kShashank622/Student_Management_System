from django.apps import AppConfig


class MarksConfig(AppConfig):
    name = 'marks'
